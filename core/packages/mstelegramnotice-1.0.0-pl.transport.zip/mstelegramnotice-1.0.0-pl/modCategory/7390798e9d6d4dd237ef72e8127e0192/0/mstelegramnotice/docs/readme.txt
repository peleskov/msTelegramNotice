--------------------
msTelegramNotice
--------------------
Author: Sergei Peleskov <info@s1temaker.ru>
--------------------
